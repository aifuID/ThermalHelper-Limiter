#!/system/bin/sh
# Hentikan proses daemon saat modul dihapus
pkill -f "ThermalHelper-Limiter/service.sh"
